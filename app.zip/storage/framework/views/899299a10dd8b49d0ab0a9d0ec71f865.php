<?php $__env->startSection('content'); ?>

<head>
    <link rel="stylesheet" href=<?php echo e(asset('css/shop-detail.css')); ?>>
</head>
    <div class="section-shode-top">
        <div class="shode-display">
            <div class="shode-display-top">
                <img src="<?php echo e(asset('storage/image/'.$shops->shop_photo_1)); ?>" alt="Error">
            </div>
            <div class="shode-display-bottom">
                <img src="<?php echo e(asset('storage/image/'.$shops->shop_photo_2)); ?>" alt="Error">
                <img src="<?php echo e(asset('storage/image/'.$shops->shop_photo_3)); ?>" alt="Error">
                <img src="<?php echo e(asset('storage/image/'.$shops->shop_photo_4)); ?>" alt="Error">
            </div>
        </div>

        <div class="shode-desc">
            <div class="shode-name"> <?php echo e($shops->shop_name); ?></div>
            <div class="shode-rate">
                <div class="shode-rate-this">
                    <img src="<?php echo e(asset('assets/star-rate.png')); ?>" alt="star">
                    <img src="<?php echo e(asset('assets/star-rate.png')); ?>"alt="star">
                    <img src="<?php echo e(asset('assets/star-rate.png')); ?>" alt="star">
                    <img src="<?php echo e(asset('assets/star-rate.png')); ?>" alt="star">
                    <img src="<?php echo e(asset('assets/star-rate-0-5.png')); ?>"alt="star">
                    <?php echo e($shops->shop_rate); ?>

                </div>
                <div class="shode-loc-logo">
                    <img src="<?php echo e(asset('assets/location-logo.png')); ?>" alt="Error">
                </div>
                <div class="shode-loc-name">
                    <?php echo e($shops->shop_location); ?>

                </div>
            </div>
            <div class="shode-price">
                IDR <?php echo e($shops->shop_price_low); ?> - <?php echo e($shops->shop_price_high); ?>

            </div>
            <div class="shode-long-desc">
                <?php echo $shops->shop_description; ?>

            </div>
            <div class="shop-address-desc">
                Address : <br>
                <?php echo e($shops->shop_address); ?>

            </div>
            <div class="button-form login-btn">
                <button type="submit" onclick="window.location.href = '<?php echo e(route('getBookingById', ['id'=>$shops->id])); ?>';">BOOK NOW</button>
            </div>
        </div>

    </div>

    <div class="section-shode-ser-fav">
        <div class="shode-ser-0">
            <div class="shode-title-ser-fav">
                Barbershop Services
            </div>
            <div class="shode-content-ser">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="shode-content-ser-1">
                    <img src="<?php echo e(asset('storage/image/'.$service->service_logo)); ?>" alt="">
                    <div class="content-ser-isi">
                        <?php echo e($service->service_name); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="shode-fav">
            <div class="shode-title-ser-fav">
                Barbershop Facility
            </div>
            <div class="shode-content-ser">
                <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="shode-content-ser-1">
                    <img src="<?php echo e(asset('storage/image/'.$facility->facility_logo)); ?>" alt="">
                    <div class="content-ser-isi">
                        <?php echo e($facility->facility_name); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="section-hair">
        <div class="section-hair-title">
            Our Hairstylist
        </div>
        <div class="hair-content">
            <?php $__currentLoopData = $hairstylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hairstylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flip-card hair-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        <div class="hair-image">
                            <img src="<?php echo e(asset('storage/image/'.$hairstylist->hairstylist_logo)); ?>" alt="">
                        </div>
                        <div class="hair-text">
                            <?php echo e($hairstylist->hairstylist_name); ?>

                        </div>
                    </div>
                    <div class="flip-card-back">
                        <div class="flip-back-top">
                            <div class="hair-text">
                                <?php echo e($hairstylist->hairstylist_name); ?>

                            </div>
                            <div class="shode-long-desc">
                                <?php echo e($hairstylist->hairstylist_description); ?>

                            </div>
                        </div>
                        <div class="flip-back-under">
                            <div class="flip-rate">
                                <div>
                                    <img src="<?php echo e(asset('assets/star-rate.png')); ?>" alt="star" style="width: 20px;"> <?php echo e($hairstylist->hairstylist_rate); ?>

                                </div>
                                <div>
                                    <?php echo e($hairstylist->hairstylist_review); ?> Reviews
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <div class="section-hair">
        <div class="section-hair-title">
            Haircut Style
        </div>
        <div class="hair-content">
            <?php $__currentLoopData = $haircuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haircut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hair-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        <div class="hair-image">
                            <img src="<?php echo e(asset('storage/image/'.$haircut->haircut_logo)); ?>" alt="">
                        </div>
                        <div class="hair-text">
                            <?php echo e($haircut->haircut_name); ?>

                        </div>
                    </div>
                </div>
            </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/user-shop-detail.blade.php ENDPATH**/ ?>