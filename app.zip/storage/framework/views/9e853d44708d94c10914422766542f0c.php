<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hairstylist Page</title>
</head>
<body>
    <form action="<?php echo e(route('createHairstylist')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="">hairstylist name</label>
        <input type="text" name="hairstylist_name">
        <label for="">hairstylist logo</label>
        <input type="file" name="hairstylist_logo">
        <label for="">hairstylist description</label>
        <input type="text" name="hairstylist_description">
        <label for="">hairstylist rate</label>
        <input type="number" name="hairstylist_rate" step="any">
        <label for="">hairstylist review</label>
        <input type="text" name="hairstylist_review">

        <button type="submit">Insert</button>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">hairstylist id</th>
            <th scope="col">hairstylist name</th>
            <th scope="col">hairstylist logo</th>
            <th scope="col">hairstylist description</th>
            <th scope="col">hairstylist rate</th>
            <th scope="col">hairstylist review</th>
            <th scope="col">delete</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $hairstylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hairstylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                <th scope="row"><?php echo e($hairstylist->id); ?></th>
                <td><?php echo e($hairstylist->hairstylist_name); ?></td>
                <td>
                    <img src="<?php echo e(asset('storage/image/'.$hairstylist->hairstylist_logo)); ?>" alt="Error" style="height: 90px" >
                </td>
                <td><?php echo e($hairstylist->hairstylist_description); ?></td>
                <td><?php echo e($hairstylist->hairstylist_rate); ?></td>
                <td><?php echo e($hairstylist->hairstylist_review); ?></td>
                <td>
                    <form action="<?php echo e(route('deleteHairstylist', ['id' => $hairstylist->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger col-md">Delete</button>
                    </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/create-hairstylist.blade.php ENDPATH**/ ?>