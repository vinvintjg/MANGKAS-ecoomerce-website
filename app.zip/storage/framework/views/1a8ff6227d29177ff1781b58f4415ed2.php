<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Page</title>
</head>
<body>
    <form action="<?php echo e(route('createProduct')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="">product name</label>
        <input type="text" name="product_name">
        <label for="">product price</label>
        <input type="numeric" name="product_price">
        <label for="">product rate</label>
        <input type="numeric" name="product_rate">
        <label for="">product logo</label>
        <input type="file" name="product_logo">

        <button type="submit">Insert</button>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">product id</th>
            <th scope="col">product name</th>
            <th scope="col">product price</th>
            <th scope="col">product rate</th>
            <th scope="col">product logo</th>
            <th scope="col">delete</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                <th scope="row"><?php echo e($product->id); ?></th>
                <td><?php echo e($product->product_name); ?></td>
                <td>Rp. <?php echo e($product->product_price); ?></td>
                <td><?php echo e($product->product_rate); ?></td>
                <td>
                    <img src="<?php echo e(asset('storage/image/'.$product->product_logo)); ?>" alt="Error" style="height: 90px" >
                </td>
                <td>
                    <form action="<?php echo e(route('deleteProduct', ['id' => $product->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger col-md">Delete</button>
                    </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/create-product.blade.php ENDPATH**/ ?>