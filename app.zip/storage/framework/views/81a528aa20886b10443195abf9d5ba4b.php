<?php $__env->startSection('content'); ?>

    <!-- <form action="<?php echo e(route('createChatting')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php
            $user = Auth::user();
        ?>

        <?php if($user && $user->role === 'admin'): ?>

            <label for="chatting_text">TExt</label>
            <input type="text" name="chatting_text">

            <label for="receiver">Receiver</label>
            <input type="text" name="receiver">

            <button type="submit">send</button>

            <p>Saya admin</p>
        <?php else: ?>

         <input type="text" name="chatting_text">

         <input type="text" name="receiver" id="receiver" readonly value="1" style="display: none">

         <button type="submit">send</button>

        <?php endif; ?>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">user</th>
            <th scope="col">text</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $chattings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user && $user->role === 'admin'): ?>
                <tr>
                    <td><?php echo e($chatting->user->id); ?></td>
                    <td><?php echo e($chatting->user->name); ?></td>
                    <td><?php echo e($chatting->chatting_text); ?></td>
                <?php else: ?>
                <tr>
                    <td><?php echo e($chatting->user->name); ?></td>
                <td><?php echo e($chatting->chatting_text); ?></td>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table> -->

    <div class="card-live-chat">
        <div class="card-live-top">
            <div class="live-title">
                <div class="live-title-section">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="7" viewBox="0 0 12 7" fill="none">
                    <path d="M11 0.5L6 5.5L1 0.5" stroke="#F8F8F8"/>
                    </svg>
                </div>
                <div class="live-title-section">
                    Chat with us !
                </div>
                <div class="live-title-section">
                    <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 8 8" fill="none">
                    <path d="M0.8 8L0 7.2L3.2 4L0 0.8L0.8 0L4 3.2L7.2 0L8 0.8L4.8 4L8 7.2L7.2 8L4 4.8L0.8 8Z" fill="#F8F8F8"/>
                    </svg>
                </div>
            </div>
            <div class="live-profile">
                <div class="live-profile-logo">
                    <img src="<?php echo e(asset('assets/icon-admin.png')); ?>" alt="error">
                </div>
                <div class="live-profile-title">
                    <div class="live-profile-title-top">
                    Admin
                    </div>
                    <div class="live-profile-title-bottom">
                    Customer Service
                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $chattings->sortBy('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($chatting->sender == '1'): ?>
                <div class="live-chat">
                    <div class="live-bubble">
                        <div class="live-bubble-time">
                            <?php echo e($chatting->created_at->addHours(7)->format('H:i')); ?>

                        </div>
                        <div class="live-bubble-text">
                            <?php echo e($chatting->chatting_text); ?>

                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="live-chat-2">
                    <div class="live-bubble-2">
                        <div class="live-bubble-text-2">
                            <?php echo e($chatting->chatting_text); ?>

                        </div>
                        <div class="live-bubble-time-2">
                            <?php echo e($chatting->created_at->addHours(7)->format('H:i')); ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <form action="<?php echo e(route('createChatting')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php
            $user = Auth::user();
        ?>

        <?php if($user && $user->role === 'admin'): ?>

            <label for="chatting_text">TExt</label>
            <input type="text" name="chatting_text">

            <label for="receiver">Receiver</label>
            <input type="text" name="receiver">

            <button type="submit">send</button>

            <p>Saya admin</p>
        <?php else: ?>
        <div class="card-live-bottom">
            <input type="text" name="chatting_text" class="live-input-place" placeholder="Your Message">
            <input type="text" name="receiver" id="receiver" readonly value="1" style="display: none">

            <button type="submit" style="border: none; background: none; padding: 0;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="14" viewBox="0 0 16 14" fill="none">
                <path d="M0 13.1765V8.23529L6.73684 6.58824L0 4.94118V0L16 6.58824L0 13.1765Z" fill="#785F3C"/>
            </svg>
            </button>

        </div>
        <?php endif; ?>
        </form>
    </div>
    <br><br><br><br><br><br><br><br>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/mangkas-chatting.blade.php ENDPATH**/ ?>