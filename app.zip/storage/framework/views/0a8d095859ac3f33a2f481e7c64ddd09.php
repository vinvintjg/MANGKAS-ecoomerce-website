<?php $__env->startSection('content'); ?>

<head>
    <link rel="stylesheet" href=<?php echo e(asset('css/product.css')); ?>>
</head>

<div class="mangkas-product">
    <div class="big-title">Product</div>

    <div class="mangkas-card">

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card card-jarak card-page-jarak">
        <div class="card_image">
            <img src="<?php echo e(asset('storage/image/'.$product->product_logo)); ?>" alt="card image">
        </div>
        <br><br><br>
        <h2><?php echo e($product->product_name); ?></h2>
        <h3>IDR <?php echo e($product->product_price); ?></h3>
        <div class="card_star">
            <img src="assets/star-rate.png" alt="star">
            <img src="assets/star-rate.png" alt="star">
            <img src="assets/star-rate.png" alt="star">
            <img src="assets/star-rate.png" alt="star">
            <img src="assets/star-rate-0.png" alt="star">
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/user-product.blade.php ENDPATH**/ ?>