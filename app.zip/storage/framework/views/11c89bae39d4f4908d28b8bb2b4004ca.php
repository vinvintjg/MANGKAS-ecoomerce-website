<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Page</title>
</head>
<body>
    <form action="<?php echo e(route('createHaircut')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="">haircut name</label>
        <input type="text" name="haircut_name">
        <label for="">haircut logo</label>
        <input type="file" name="haircut_logo">

        <button type="submit">Insert</button>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">haircut id</th>
            <th scope="col">haircut name</th>
            <th scope="col">haircut logo</th>
            <th scope="col">delete</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $haircuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haircut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                <th scope="row"><?php echo e($haircut->id); ?></th>
                <td><?php echo e($haircut->haircut_name); ?></td>
                <td>
                    <img src="<?php echo e(asset('storage/image/'.$haircut->haircut_logo)); ?>" alt="Error" style="height: 90px" >
                </td>
                <td>
                    <form action="<?php echo e(route('deleteHaircut', ['id' => $haircut->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger col-md">Delete</button>
                    </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/create-haircut.blade.php ENDPATH**/ ?>