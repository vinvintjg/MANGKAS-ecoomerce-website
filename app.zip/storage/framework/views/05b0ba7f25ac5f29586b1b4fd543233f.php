<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Page</title>
</head>
<body>
    <form action="<?php echo e(route('createAgenda')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="">hairstylist</label>
        <select name="hairstylist_id" id="hairstylist_id">
            <?php $__currentLoopData = $hairstylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hairstylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?= $hairstylist['id'] ?>" name="hairstylist_id"><?= $hairstylist['hairstylist_name'] ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="">date</label>
        <input type="date" name="date">
        <label for="">hour</label>
        <input type="time" name="hour">
        <label for="">status</label>
        <input type="text" name="status">

        <button type="submit">Insert</button>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">agenda id</th>
            <th scope="col">hairstylist_id</th>
            <th scope="col">hairstylist_name</th>
            <th scope="col">agenda date</th>
            <th scope="col">agenda hour</th>
            <th scope="col">agenda status</th>
            <th scope="col">delete</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                <th scope="row"><?php echo e($agenda->id); ?></th>
                <td><?php echo e($agenda->hairstylist_id); ?></td>
                <td><?php echo e($agenda->hairstylist->hairstylist_name); ?></td>
                <td>Rp. <?php echo e($agenda->date); ?></td>
                <td><?php echo e($agenda->hour); ?></td>
                <td><?php echo e($agenda->status); ?></td>
                <td>
                    <form action="<?php echo e(route('deleteAgenda', ['id' => $agenda->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger col-md">Delete</button>
                    </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/create-agenda.blade.php ENDPATH**/ ?>