<?php $__env->startSection('content'); ?>

<head>
    <link rel="stylesheet" href=<?php echo e(asset('css/product.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/shop.css')); ?>>
</head>

<div class="mangkas-product">
    <div class="big-title">Shop</div>

    <div class="mangkas-card">

    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shop-card-1 card">
        <div class="shop-img">
            <img src="<?php echo e(asset('storage/image/'.$shop->shop_photo_1)); ?>" alt="card image">
        </div>
        <div class="shop-text-2">
            <div class="shop-top-text">
                <?php echo e($shop->shop_name); ?>

            </div>
            <div class="shop-mid-text">
                <div class="shop-rate">
                    <img src="assets/star-rate.png" alt="star">
                    <?php echo e($shop->shop_rate); ?>

                </div>
                <div class="shop-location">
                    <?php echo e($shop->shop_location); ?>

                </div>
            </div>
            <div class="shop-bot-text">
                <div class="shop-service">
                    <?php
                        $count = 0;
                    ?>

                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($service->shop_id == $shop->shopid && $count < 3): ?>
                            <?php echo e($service->service_name); ?>

                            <?php if($count<2): ?>&bull;<?php endif; ?>
                            <?php
                                $count++;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="shop-button">
                <button onclick="window.location.href = '<?php echo e(route('getShopById', ['id'=>$shop->id])); ?>';">BOOKING</button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/user-shop.blade.php ENDPATH**/ ?>