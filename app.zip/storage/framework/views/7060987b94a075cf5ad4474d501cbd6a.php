<?php $__env->startSection('content'); ?>

    <head>
        
        <link rel="stylesheet" href=<?php echo e(asset('css/form.css')); ?>>
    </head>

    <div class="section-formulir">
        <div class="big-title">Booking Detail</div>
        <form action="<?php echo e(route('createBooking')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-column">
                    <div class="form-section-label">
                        Personal
                    </div>
                    <hr>
                    <label for="booking_name" class="form-label">Name</label>
                    <input type="text" class="form-input"  name="booking_name" value="<?php echo e(old('booking_name')); ?>" placeholder="Enter Your Name">
                    <?php $__errorArgs = ['booking_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="booking_phone" class="form-label">Phone</label>
                    <input type="text" class="form-input" name="booking_phone" value="<?php echo e(old('booking_phone')); ?>" placeholder="Enter Your Phone">
                    <?php $__errorArgs = ['booking_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="booking_gender" class="form-label">Gender</label>
                    <div class="select-wrapper">
                        <select name="booking_gender" id="booking_gender" class="form-input">
                            <option value="-1" name="booking_gender">Choose Your Gender</option>
                            <option value="Male" name="booking_gender" <?php echo e(old('booking_gender') == 'Male' ? 'selected' : ''); ?>>Male</option>
                            <option value="Female" name="booking_gender" <?php echo e(old('booking_gender') == 'Female' ? 'selected' : ''); ?>>Female</option>
                        </select>
                        <span class="dropdown-icon" for="booking_gender">&#9660;</span>
                    </div>
                    <?php $__errorArgs = ['booking_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-column">
                    <div class="form-section-label">
                        Barbershop
                    </div>
                    <hr>

                    <label for="shop_name" class="form-label">Barbershop</label>
                    <div class="select-wrapper">
                        <select name="shop_id" id="shop_id" class="form-input">
                            <option value="<?= $shopId ?>" name="shop_id"><?= $shops['shop_name'] ?></option>
                        </select>
                    </div>
                    <?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="serv-1-line">
                        <label for="booking_service" class="form-label">Services</label>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="serv-1-baris">
                                <label class="container"><?php echo e($service['service_name']); ?>

                                    <input type="checkbox" value="<?php echo e($service['id']); ?>" name="booking_service[]"
                                        class="service-checkbox" <?php echo e(in_array($service['id'], old('booking_service', [])) ? 'checked' : ''); ?>>
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__errorArgs = ['booking_service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="form-section-label">
                Detail Services
            </div>
            <hr>

            <div class="form-row">
                <div class="form-column">
                    <label for="booking_haircut" class="form-label">Haircut Style</label>
                    <div class="select-wrapper">
                        <select name="booking_haircut" id="booking_haircut" class="form-input" placeholder="Enter Your Haircut Style">
                            <option value="-1" name="">Choose Haircut</option>
                            <?php $__currentLoopData = $haircuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haircut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($haircut['id']); ?>" name="booking_haircut" <?php echo e(old('booking_haircut') == $haircut['id'] ? 'selected' : ''); ?>>
                                    <?php echo e($haircut['haircut_name']); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="dropdown-icon">&#9660;</span>
                    </div>
                    <?php $__errorArgs = ['booking_haircut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="booking_note" class="form-label">Note</label>
                    <input type="text" class="form-input" name="booking_note" placeholder="Enter Your Note" value="<?php echo e(old('booking_note')); ?>">
                    <?php $__errorArgs = ['booking_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-column">
                    <label for="filter_date" class="form-label">Date</label>
                    <input type="date" class="form-input" name="filter_date" id="filter_date">

                    <table class="table_agenda" id="agenda_table">
                        <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($agenda->status !== 'Unavailable'): ?>
                            <td class="agenda_row" data-date="<?php echo e(date('Y-m-d', strtotime($agenda->date))); ?>">
                                <input type="radio" name="agenda_id" id="<?php echo e($agenda->id); ?>" value="<?php echo e($agenda->id); ?>" <?php echo e(old('agenda_id') == $agenda->id ? 'checked' : ''); ?>>
                                <label for="<?php echo e($agenda->id); ?>" class="label_agenda">
                                    <h4><?php echo e($agenda->hairstylist->hairstylist_name); ?></h4>
                                    <p><?php echo e(date('H:i', strtotime($agenda->hour))); ?> | <?php echo e(date('d M', strtotime($agenda->date))); ?></p>
                                </label>
                            </td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php $__errorArgs = ['agenda_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-section-label">
                Payment
            </div>
            <hr>

            <div class="form-row">
                <div class="form-column">
                    <label for="booking_payment_total" class="form-label">Payment Detail</label>
                    <div class="form-column-pay">
                        <div class="form-total-pay">Total Harga:</div>
                        <div class="form-total-pay">Rp <span id="total-price"></span></div>
                    </div>
                    <input type="text" class="form-input" name="booking_payment_total" id="booking_payment_total"
                        readonly style="display: none;" placeholder="Enter Your Payment Detail">
                </div>
                <div class="form-column">
                    <label for="booking_payment_method" class="form-label">Transaction Method</label>
                    <input type="text" class="form-input" name="booking_payment_method" placeholder="Enter Your Transaction Method" value="<?php echo e(old('booking_payment_method')); ?>">
                    <?php $__errorArgs = ['booking_payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                </div>
            </div>
            <div class="form-pay-section">
                <div class="form-section-label">
                    Proof of Payment
                </div>

                <div class="form-file">
                    <img src="<?php echo e(asset('assets/pay-file.png')); ?>" alt="logo">
                    <div class="form-total-pay">Format: JPG, JPEG, PNG, max 10 MB</div>
                    <input type="file" class="custom-file-input" name="booking_payment_photo">
                </div>
                <?php $__errorArgs = ['booking_payment_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="button-form button-width">
                <button type="submit">SUBMIT</button>
            </div>

        </form>

    </div>



    <script>
        const filterInput = document.getElementById('filter_date');
        const agendaRows = document.getElementsByClassName('agenda_row');

        filterInput.addEventListener('input', function() {
            const filterDate = this.value;

            for (let i = 0; i < agendaRows.length; i++) {
                const agendaDate = agendaRows[i].getAttribute('data-date');

                if (agendaDate === filterDate) {
                    agendaRows[i].style.display = '';
                } else {
                    agendaRows[i].style.display = 'none';
                }
            }
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            var services = [
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        id: '<?php echo e($service->id); ?>',
                        price: '<?php echo e($service->service_price); ?>'
                    },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ];

            function calculateTotalPrice() {
                var totalPrice = 0;
                $('.service-checkbox:checked').each(function() {
                    var serviceId = $(this).val();
                    var foundService = services.find(function(service) {
                        return service.id === serviceId;
                    });

                    if (foundService) {
                        var servicePrice = parseInt(foundService.price);
                        totalPrice += servicePrice;
                    }
                });

                $('#total-price').text(totalPrice);
                $('#booking_payment_total').val(totalPrice);
            }

            $('.service-checkbox').on('change', function() {
                calculateTotalPrice();
            });

            $('.service-checkbox').each(function() {
                var serviceId = $(this).val();
                var foundService = services.find(function(service) {
                    return service.id === serviceId;
                });

                if (foundService) {
                    var servicePrice = parseInt(foundService.price);
                    $(this).data('price', servicePrice);
                }
            });

            calculateTotalPrice();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/user-booking.blade.php ENDPATH**/ ?>