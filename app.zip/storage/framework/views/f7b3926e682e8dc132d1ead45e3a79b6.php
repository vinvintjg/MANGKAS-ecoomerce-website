<?php $__env->startSection('content'); ?>

    <head>
        <title>FAQ</title>
        <link
            href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,500;0,600;0,700;1,300;1,600&display=swap"
            rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
        <link rel="stylesheet" href=<?php echo e(asset('css/faq.css')); ?>>
        <link rel="stylesheet" href=<?php echo e(asset('css/form.css')); ?>>
        <link rel="stylesheet" href="styles.css" />
    </head>

    <body>

        <div class="section-faq">
            <div class="big-title">FAQ</div>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="drop">
                    <div class="drop-item">
                        <button id="drop-button-1" aria-expanded="false">
                            <span class="drop-title"><?php echo e($faq->faq_question); ?></span>
                            <span class="icon" aria-hidden="true"></span>
                        </button>
                        <div class="drop-content">
                            <p>
                                <?php echo e($faq->faq_answer); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </body>



    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MANGKAS-ecoomerce-website\resources\views/user-faq.blade.php ENDPATH**/ ?>